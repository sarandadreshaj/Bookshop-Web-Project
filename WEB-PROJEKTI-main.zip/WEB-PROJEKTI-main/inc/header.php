 <header>
            <img src="img/book-64.png" id="ikone">
        <ul id="lista">
            <li class="listaLi">
                <a class="linku" href="index.php">HOME</a>
            </li>
            <li class="listaLi">
                <a class="linku" href="login.php">LOG IN</a>
            </li>
            <li class="listaLi">
                <a class="linku" href="register.php">REGISTER</a>
             </li>
            <li class="listaLi">
                <a class="linku" href="blog.php">BLOG</a>
            </li>
            <li class="listaLi">
                <a class="linku" href="contactus.php">CONTACT US</a>
            </li>
            <li class="listaLi">
                <a class="linku" href="aboutus.php">ABOUT US</a>
            </li>
        </ul>
    </header>