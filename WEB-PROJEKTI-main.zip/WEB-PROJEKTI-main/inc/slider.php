<div class="sliderdiv">
            <div class="slidermain">
                <div class="slider">
                    <div class="slide">         
                        <img src="https://i.imgur.com/t6PEL28.png" alt="sliderfoto" class="sliderfoto">
                        <div class="moviedesc">
                            <h1>The Handmaid's tale</h1>
                            <h2 class="moviegenre">English, Paperback</h2>
                        </div>  
                    </div>

                    <div class="slide">
                        <img src="https://i.imgur.com/wUr7A8g.png" alt="sliderfoto" class="sliderfoto">
                        <div class="moviedesc">
                            <h1>Girl, Woman and other</h1>
                            <h2 class="moviegenre">English, Hardback</h2>
                        </div>  
                    </div>

                    <div class="slide">
                        <img src="https://i.imgur.com/09ulDPJ.png" alt="sliderfoto" class="sliderfoto">
                        <div class="moviedesc">
                            <h1>Gotta Get Theroux this</h1>
                            <h2 class="moviegenre">English, Hardback</h2>
                        </div>  
                    </div>

                    <div class="slide">
                        <img src="https://i.imgur.com/HLzY1RV.png" alt="sliderfoto" class="sliderfoto">
                        <div class="moviedesc">
                            <h1>Catch and Kill</h1>
                            <h2 class="moviegenre">English, Hardback</h2>
                        </div>  
                    </div>


                </div>
                <div class="controls">
                    <a class="prev">&#10094;</a>
                    <a class="next">&#10095;</a>
                </div>
                
            </div>
        </div>